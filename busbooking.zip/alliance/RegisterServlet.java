package com.alliance;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String firstName=request.getParameter("firstname");
		String lastName=request.getParameter("lastname");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		String name=firstName+" "+lastName;
		SqlConn sqlConn = new SqlConn();
		try {
			Connection con = sqlConn.returnCon();
			//String sqlQuery= "SELECT * FROM BUSLIST ";
			String sqlQuery= "insert into UserInfo(Name1,Email,Password1,Gender) values('"+name+"','"+email+"','"+password+"','"+gender+"')"; 
			String query="insert into UserInfo(Name1,Email,Password1,Gender) values(?,?,?,?)";
			PreparedStatement pr=con.prepareStatement(query);
			pr.setString (1,name);
		    pr.setString (2,email);
		    pr.setString (3,password);
		    pr.setString (4,gender);
			System.out.println(sqlQuery);
			pr.executeUpdate();
			con.close();
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<script type=\"text/javascript\">");
		    out.println("alert('Redirecting to Login page.');");
		    out.println("</script>");
			response.sendRedirect("Login.jsp");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//request.getRequestDispatcher("Home.jsp").forward(request, response);
	}

}

package com.alliance;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BookTicketServlet
 */
@WebServlet("/BookTicketServlet")
public class BookTicketServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookTicketServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("checkingg");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String origin=request.getParameter("origin");
		request.setAttribute("origin", origin);
		String destination=request.getParameter("destination");
		request.setAttribute("destination",destination);
		String seatCapacity=request.getParameter("seatCapacity");
		request.setAttribute("seatCapacity",seatCapacity);
		String departureTime=request.getParameter("departureTime");
		System.out.println(departureTime);
		request.setAttribute("departureTime",departureTime);
		String arrivalTime=request.getParameter("arrivalTime");
		request.setAttribute("arrivalTime",arrivalTime);
		String fare=request.getParameter("fare");
		request.setAttribute("fare",fare);
		String nBusId=request.getParameter("nBusId");
		request.setAttribute("nBusId",nBusId);
		String journeyDate=request.getParameter("journeyDate");
		request.setAttribute("journeyDate",journeyDate);
		System.out.println(journeyDate);
		SqlConn sqlConn = new SqlConn();
		try {
			Connection con = sqlConn.returnCon();
			String sqlQuery= "select s.stopName from stops s inner join city c on s.nCityId=c.nCityId where cityname='"+origin+"'";
			String sqlQuery1= "select s.stopName from stops s inner join city c on s.nCityId=c.nCityId where cityname='"+destination+"'";
			System.out.println(sqlQuery);
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sqlQuery);
			
		    List<String> board=new ArrayList<String>();
		    List<String> drop=new ArrayList<String>();
			//request.setAttribute("busDetails", busDetails);
			
			while(rs.next()) {
				board.add(rs.getString(1));
				
			}
			rs.close();
			ResultSet rs1=st.executeQuery(sqlQuery1);
			while(rs1.next()) {
				drop.add(rs1.getString(1));
				
			}
			for(int i=0;i<drop.size();++i)
			{
				System.out.println(drop.get(i));
			}
			request.setAttribute("boarding",board);
			request.setAttribute("dropping",drop);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("BookSeat.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		// TODO Auto-generated method stub
		//doGet(request, response);
		String source=request.getParameter("source");
		String destination=request.getParameter("destination");
		String departureTime=request.getParameter("departureTime");
		String arrivalTime=request.getParameter("arrivalTime");
		String journeyDate=request.getParameter("journeyDate");
		String boarding=request.getParameter("boardingPoint");
		String dropping=request.getParameter("droppingPoint");
		String seats=request.getParameter("seats");
		String fare=request.getParameter("fare");
		String seatCount[]=seats.split("\\,");
		System.out.println(Arrays.toString(seatCount));
		System.out.println(seatCount.length-1);
		System.out.println(journeyDate);
	}

}

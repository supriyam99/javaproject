package com.alliance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class BookTicketDAO 
{
   public static void insTicket(int nBusId,String email,int seats,int noSeats,String journeyDate,float fare)
   {
	   SqlConn sqlConn = new SqlConn();
		try {
			Connection con = sqlConn.returnCon();
			//String sqlQuery= "SELECT * FROM BUSLIST ";
			String query="insert into bookingdetails(nBusId,email,Seats,NoOfSeats,JourneyDate,DateOfBooking,fare,bActive) values(?,?,?,?,?,?,?,?)";
			PreparedStatement pr=con.prepareStatement(query);
			pr.setInt (1,nBusId);
		    pr.setString(2,email);
		    pr.setInt (3,seats);
		    pr.setInt (4,noSeats);
		    pr.setDate(5,Date.valueOf(journeyDate));
		    pr.setDate(6, java.sql.Date.valueOf(java.time.LocalDate.now()));
		    pr.setFloat(7,fare);
		    pr.setInt(8,1);
			System.out.println(query);
			pr.executeUpdate();
			pr.close();
			//String query1=" select last_insert_id() from bookingdetails";
			con.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	  
   }
   public static int returnBookingId()
   {
	   int id=-1;
	   SqlConn sqlConn = new SqlConn();
		try {
			Connection con = sqlConn.returnCon();
			//String sqlQuery= "SELECT * FROM BUSLIST ";
			String query="select last_insert_id() from bookingdetails";
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(query);
			System.out.println(query);
			while(rs.next()) {
				System.out.println(rs.getInt(1));
				id=rs.getInt(1);
			}
			
			con.close();
			return id;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	   
   }
}

package com.alliance;
import java.sql.*;


public class SqlConn 
{
	static Connection con;
	public static Connection returnCon() throws SQLException,ClassNotFoundException,Exception
	{

			Class.forName("com.mysql.cj.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/OnlineBusBooking","root","boardexams12"); 
			return con;
			

	
		
	}
	 
	

}

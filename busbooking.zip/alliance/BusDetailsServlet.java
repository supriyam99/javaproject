package com.alliance;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BusDetailsServlet
 */
@WebServlet("/BusDetailsServlet")
public class BusDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BusDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String destination=request.getParameter("destination");
		String source=request.getParameter("source");
		String journeyDate=request.getParameter("jDate");
		
		System.err.println(destination);
		SqlConn sqlConn = new SqlConn();
		try {
			Connection con = sqlConn.returnCon();
			//String sqlQuery= "SELECT * FROM BUSLIST ";
			String sqlQuery= "SELECT * FROM BUSLIST WHERE ORIGIN='"+source+"' AND DESTINATION='"+destination+"'"; 
			System.out.println(sqlQuery);
			Statement st=con.createStatement();
			ResultSet busDetails=st.executeQuery(sqlQuery);
			System.out.println("Data:"+busDetails);
			request.setAttribute("busDetails", busDetails);
			List<BusList> busList=new ArrayList<BusList>();
			while(busDetails.next()) {
				busList.add(new BusList(busDetails.getInt(1),busDetails.getString(2), busDetails.getString(3),busDetails.getString(4),busDetails.getString(5),busDetails.getString(6),busDetails.getInt(7),busDetails.getString(8),busDetails.getString(9),busDetails.getFloat(10),busDetails.getString(11)));
				
			}
			request.setAttribute("busList", busList);
			request.setAttribute("journeyDate",journeyDate);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("check");
		request.getRequestDispatcher("Home.jsp").forward(request, response);
		//doGet(request, response);
	}

}

package com.alliance;

import java.sql.*;

public class BusList {
	public BusList(int nBusId, String travelAgency, String origin, String startStop, String destination, String endStop,
			int seatCapacity, String departureTime, String arrivalTime, float fare, String type) {
		this.nBusId = nBusId;
		this.travelAgency = travelAgency;
		this.origin = origin;
		this.startStop = startStop;
		this.destination = destination;
		this.endStop = endStop;
		this.seatCapacity = seatCapacity;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.fare = fare;
		this.type = type;
	}

	private int nBusId;
	private String travelAgency;
	private String origin;
	private String startStop;
	private String destination;
	private String endStop;
	private int seatCapacity;
	private String departureTime;
	private String arrivalTime;
	private float fare;
	private String type;

	public int getnBusId() {
		return nBusId;
	}

	public void setnBusId(int nBusId) {
		this.nBusId = nBusId;
	}

	public String getTravelAgency() {
		return travelAgency;
	}

	public void setTravelAgency(String travelAgency) {
		this.travelAgency = travelAgency;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getStartStop() {
		return startStop;
	}

	public void setStartStop(String startStop) {
		this.startStop = startStop;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getEndStop() {
		return endStop;
	}

	public void setEndStop(String endStop) {
		this.endStop = endStop;
	}

	public int getSeatCapacity() {
		return seatCapacity;
	}

	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}

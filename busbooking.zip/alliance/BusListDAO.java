package com.alliance;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BusListDAO 
{
   public List<BusList> list() throws SQLException,ClassNotFoundException,Exception
   {
	   List<BusList> busList=new ArrayList<BusList>();
	   try (
	            Connection connection = SqlConn.returnCon();
	            PreparedStatement statement = connection.prepareStatement("SELECT * FROM BusList");
	            ResultSet resultSet = statement.executeQuery();
	        )
	   
	   {
           while (resultSet.next()) {
               BusList blist = new BusList(resultSet.getInt("nBusId"),resultSet.getString("TravelAgency"),resultSet.getString("Origin"),resultSet.getString("StartStop"),resultSet.getString("Destination"),resultSet.getString("EndStop"),resultSet.getInt("SeatCapacity"),resultSet.getString("DepartureTime"), resultSet.getString("ArrivalTime"),resultSet.getInt("Fare"),resultSet.getString("Type1"));
               
               busList.add(blist);
               
           }
       }
	   return busList;
   }

}

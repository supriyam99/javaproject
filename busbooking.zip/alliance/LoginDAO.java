package com.alliance;
import java.sql.*;

public class LoginDAO 
{
	String user,pass;
	public String uName;

	public boolean validUser(String userName,String password)
	{
		SqlConn sqlConn = new SqlConn();
		try
		{
			Connection con=sqlConn.returnCon();
			String sqlQuery= "SELECT * FROM UserInfo WHERE email='"+userName+"' AND password1='"+password+"'"; 
			//System.out.println(sqlQuery);
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery(sqlQuery);
			while(rs.next())
			{
                user = rs.getString("Email");
                pass = rs.getString("Password1");
                uName= rs.getString("Name1");
		    }
			System.out.println(user+" "+pass);
			if(user.equals(userName) && pass.equals(password))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
				
		
	}

}

